﻿namespace Hahn.ApplicatonProcess.July2021.Domain.Constants
{
    public static class ServiceConstantsMsgs
    {
        #region userControlMsgs
        public const string idGreaterThanCeroMsg = "Id must be greater than 0.";
        public const string createUserFailedMsg = "Something went wrong inside CreateUser action: ";
        public const string userObjNullMsg = "User object is null";
        public const string invalidUserMsg = "Invalid User object sent from client.";
        public const string invalidAssets = "Invalid asset(s), please verify";
        public const string getUserFailedMsg = "Something went wrong inside GetUser action:";
        public const string deleteUserFailedMsg = "Something went wrong inside DeleteOwner action:";
        #endregion

        #region general
        public const string internalServerErrorMsg = "Internal server error";
        #endregion
    }
}
