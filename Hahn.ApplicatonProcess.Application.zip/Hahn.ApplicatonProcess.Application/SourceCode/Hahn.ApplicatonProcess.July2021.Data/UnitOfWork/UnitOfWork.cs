﻿using Hahn.ApplicatonProcess.July2021.Data.Repositories;
using Hahn.ApplicatonProcess.July2021.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Hahn.ApplicatonProcess.July2021.Data.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDBContext _dbContext;
        public IUserRepository Users { get; private set; }
        public IAssetRepository Assets { get; private set; }

        public UnitOfWork(ApplicationDBContext context)
        {
            _dbContext = context;

            Users = new UserRepository(_dbContext);

            Assets = new AssetRepository(_dbContext);

        }

        public int Complete()
        {
            return _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
