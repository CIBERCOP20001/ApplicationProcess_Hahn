﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hahn.ApplicatonProcess.July2021.Domain.Models
{
    /// <summary>
    /// Asset Model
    /// </summary>
    public class Asset
    {
        //Autoincrement index for Assets table
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AssetId { get; set; }

        public string Id { get; set; }

        public string Symbol { get; set; }

        public string Name { get; set; }

    }
}
