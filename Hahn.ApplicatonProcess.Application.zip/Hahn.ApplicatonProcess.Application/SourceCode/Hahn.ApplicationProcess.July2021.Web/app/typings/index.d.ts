/// <reference path="globals/url-search-params-typing/index.d.ts" />
/// <reference path="globals/whatwg-fetch/index.d.ts" />
/// <reference path="globals/whatwg-streams/index.d.ts" />
