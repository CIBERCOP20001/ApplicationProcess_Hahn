import Aurelia from 'aurelia';
import { MyApp } from './my-app';
Aurelia
    .app(MyApp)
    .start();
