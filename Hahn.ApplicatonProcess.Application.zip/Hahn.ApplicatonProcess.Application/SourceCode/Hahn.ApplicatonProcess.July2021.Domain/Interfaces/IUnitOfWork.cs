﻿using System;

namespace Hahn.ApplicatonProcess.July2021.Domain.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IUserRepository Users { get; }
        //IAssetRepository Assets { get; }
        int Complete();
    }
}
