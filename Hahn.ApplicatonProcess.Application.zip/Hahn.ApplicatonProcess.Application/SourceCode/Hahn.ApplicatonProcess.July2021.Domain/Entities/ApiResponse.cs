﻿using System.Collections.Generic;

namespace Hahn.ApplicatonProcess.July2021.Domain.Models
{
    public class ApiResponse
    {
        public IEnumerable<Asset> Data { get; set; }
    }
}
