using System;
using Xunit;

namespace Hahn.ApplicatonProcess.July2021.Data.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
