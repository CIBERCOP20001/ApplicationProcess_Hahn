
import { HttpClient } from 'aurelia-fetch-client';

export class MyApp {
    public message = 'Hello World   world!';
}
