﻿using Hahn.ApplicatonProcess.July2021.Domain.Interfaces;
using Hahn.ApplicatonProcess.July2021.Domain.Models;

namespace Hahn.ApplicatonProcess.July2021.Data.Repositories
{
   public class AssetRepository :  GenericRepository<Asset>, IAssetRepository
    {
        public AssetRepository(ApplicationDBContext context) : base(context)
        {

        }
    }
}
