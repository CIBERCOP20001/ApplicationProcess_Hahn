﻿using Hahn.ApplicatonProcess.July2021.Domain.Interfaces;
using Hahn.ApplicatonProcess.July2021.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hahn.ApplicatonProcess.July2021.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssetController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IGenericRepository<Asset> _assetRepository;

        public AssetController(IUnitOfWork unitOfWork, IGenericRepository<Asset> assetRepository)
        {
            _unitOfWork = unitOfWork;
            _assetRepository = assetRepository;
        }

        // GET: api/<AssetController>
        [HttpGet]
        public IEnumerable<Asset> Get()
        {
            return _assetRepository.GetAll();
        }
    }
}
