﻿using FluentValidation;
using Hahn.ApplicatonProcess.July2021.Domain.Models;

namespace Hahn.ApplicatonProcess.July2021.Domain.Validators
{
    public class UserValidator : AbstractValidator<User>
    {
        public UserValidator()
        {
            RuleFor(user => user.FirstName).MinimumLength(3);
            RuleFor(user => user.LastName).MinimumLength(3);
            RuleFor(user => user.Age).GreaterThan(18);
            RuleFor(user => user.Email).EmailAddress().When(user => user.Email != null);

        }
    }
}
