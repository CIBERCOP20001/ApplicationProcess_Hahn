export class MyApp {
    constructor() {
        this.message = 'Hello World   world!';
    }
}
